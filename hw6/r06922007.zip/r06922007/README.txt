資工碩一 r06922007 楊承勳

platform : Matlab

程式可以用matlab直接執行, p11.m for 第11題, 其他依此類推.

第11題會印出所有gamma, lambda的組合以及相對應的Ein

第12題會印出所有gamma, lambda的組合以及相對應的Eout

第13題會印出所有的lambda以及相對應的Ein

第14題會印出所有的lambda以及相對應的Eout

第15題會印出所有的lambda以及相對應的Ein

第16題會印出所有的lambda以及相對應的Eout