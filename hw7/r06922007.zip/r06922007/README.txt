資工碩一 r06922007 楊承勳

platform : Matlab

程式可以用matlab直接執行, p11.m for 第11題, 其他依此類推.

第11題會畫出一張圖, x軸為t(1~300), y軸是Ein(gt), 最後再印出Ein(g1)和alpha1.

第13題會畫出一張圖, x軸為t, y軸是Ein(Gt), 最後再印出Ein(G).

第14題會畫出一張圖, x軸為t, y軸是Ut, 最後再印出U_2和U_T.

第15題會畫出一張圖, x軸為t, y軸是Eout(gt), 最後再印出Eout(g1).

第16題會畫出一張圖, x軸為t, y軸是Eout(Gt), 最後再印出Eout(G).